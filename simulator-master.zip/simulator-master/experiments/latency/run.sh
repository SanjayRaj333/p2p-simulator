./simulate.sh 7 32 100 DBS
#./compute_averages.sh 7_32_DBS  > DBS.txt
./simulate.sh 7 32 100 DBS2
#./compute_averages.sh 7_32_DBS2 > DBS2.txt
./simulate.sh 7 32 100 DBS3
#./compute_averages.sh 7_32_DBS3 > DBS3.txt
