"""
@package simulator
monitor_dbs module
"""

import struct

from .common import Common
from .peer_dbs_latency import Peer_DBS_latency


class Monitor_DBS_latency(Peer_DBS_latency):
    
    pass
