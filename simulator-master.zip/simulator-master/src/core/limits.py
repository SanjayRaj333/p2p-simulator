"""
@package simulator
limits module
"""

class Limits:

    MAX_CHUNK_NUMBER = 65536

